package com.mahaboard.result;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class AdminLoginActivity extends AppCompatActivity {

    private EditText etAdminId, etPassword;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);

        prefs = getSharedPreferences("AdminPrefs", MODE_PRIVATE);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Admin Login");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        etAdminId  = findViewById(R.id.etAdminId);
        etPassword = findViewById(R.id.etPassword);
        Button btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(v -> {
            String enteredId  = etAdminId.getText().toString().trim();
            String enteredPwd = etPassword.getText().toString().trim();

            // Get saved credentials (defaults: admin / maha@2024)
            String savedId  = prefs.getString("admin_id", "admin");
            String savedPwd = prefs.getString("admin_password", "maha@2024");

            if (enteredId.equals(savedId) && enteredPwd.equals(savedPwd)) {
                startActivity(new Intent(this, AdminPanelActivity.class));
                finish();
            } else {
                Toast.makeText(this, "चुकीचा ID किंवा Password!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
