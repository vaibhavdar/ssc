package com.mahaboard.result;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class AdminPanelActivity extends AppCompatActivity {

    private SharedPreferences prefs;
    private SharedPreferences.Editor editor;

    // URL Fields
    private EditText etUrlSsc, etUrlHsc, etUrlBoard;

    // Unity Ads Fields
    private EditText etGameId, etBannerPid, etInterstitialPid, etRewardedPid;

    // Toggles
    private Switch switchAdsEnabled, switchTestMode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_panel);

        prefs  = getSharedPreferences("AdminPrefs", MODE_PRIVATE);
        editor = prefs.edit();

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("🔐 Admin Panel");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        bindViews();
        loadSavedValues();
        setupButtons();
    }

    private void bindViews() {
        // URLs
        etUrlSsc           = findViewById(R.id.etUrlSsc);
        etUrlHsc           = findViewById(R.id.etUrlHsc);
        etUrlBoard         = findViewById(R.id.etUrlBoard);

        // Unity Ads
        etGameId           = findViewById(R.id.etGameId);
        etBannerPid        = findViewById(R.id.etBannerPlacement);
        etInterstitialPid  = findViewById(R.id.etInterstitialPlacement);
        etRewardedPid      = findViewById(R.id.etRewardedPlacement);

        // Toggles
        switchAdsEnabled   = findViewById(R.id.switchAdsEnabled);
        switchTestMode     = findViewById(R.id.switchTestMode);
    }

    private void loadSavedValues() {
        // URLs
        etUrlSsc.setText(prefs.getString("url_ssc",   "https://sscresult.mkcl.org"));
        etUrlHsc.setText(prefs.getString("url_hsc",   "https://hscresult.mkcl.org"));
        etUrlBoard.setText(prefs.getString("url_board","https://mahahsscboard.in"));

        // Unity Ads
        etGameId.setText(prefs.getString("unity_game_id", ""));
        etBannerPid.setText(prefs.getString("banner_placement_id", "Banner_Android"));
        etInterstitialPid.setText(prefs.getString("interstitial_placement_id", "Interstitial_Android"));
        etRewardedPid.setText(prefs.getString("rewarded_placement_id", "Rewarded_Android"));

        // Toggles
        switchAdsEnabled.setChecked(prefs.getBoolean("ads_enabled", true));
        switchTestMode.setChecked(prefs.getBoolean("test_mode", false));
    }

    private void setupButtons() {
        // Save URLs
        Button btnSaveUrls = findViewById(R.id.btnSaveUrls);
        btnSaveUrls.setOnClickListener(v -> {
            String ssc   = etUrlSsc.getText().toString().trim();
            String hsc   = etUrlHsc.getText().toString().trim();
            String board = etUrlBoard.getText().toString().trim();

            if (ssc.isEmpty() || hsc.isEmpty() || board.isEmpty()) {
                Toast.makeText(this, "सर्व URLs भरा!", Toast.LENGTH_SHORT).show(); return;
            }

            editor.putString("url_ssc",   ssc);
            editor.putString("url_hsc",   hsc);
            editor.putString("url_board", board);
            editor.apply();
            Toast.makeText(this, "✅ URLs Save केले!", Toast.LENGTH_SHORT).show();
        });

        // Save Ads Settings
        Button btnSaveAds = findViewById(R.id.btnSaveAds);
        btnSaveAds.setOnClickListener(v -> {
            editor.putString("unity_game_id",             etGameId.getText().toString().trim());
            editor.putString("banner_placement_id",       etBannerPid.getText().toString().trim());
            editor.putString("interstitial_placement_id", etInterstitialPid.getText().toString().trim());
            editor.putString("rewarded_placement_id",     etRewardedPid.getText().toString().trim());
            editor.putBoolean("ads_enabled",              switchAdsEnabled.isChecked());
            editor.putBoolean("test_mode",                switchTestMode.isChecked());
            editor.apply();
            Toast.makeText(this, "✅ Ads Settings Save केले! App Restart करा.", Toast.LENGTH_LONG).show();
        });

        // Change Admin Password
        Button btnChangePwd = findViewById(R.id.btnChangePassword);
        btnChangePwd.setOnClickListener(v -> {
            EditText input = new EditText(this);
            input.setHint("नवीन Password");
            new AlertDialog.Builder(this)
                .setTitle("🔑 Password बदला")
                .setView(input)
                .setPositiveButton("Save", (d, w) -> {
                    String p = input.getText().toString().trim();
                    if (!p.isEmpty()) { editor.putString("admin_password", p).apply(); Toast.makeText(this, "✅ Password बदलला!", Toast.LENGTH_SHORT).show(); }
                })
                .setNegativeButton("रद्द करा", null).show();
        });

        // Change Admin ID
        Button btnChangeId = findViewById(R.id.btnChangeId);
        btnChangeId.setOnClickListener(v -> {
            EditText input = new EditText(this);
            input.setHint("नवीन Admin ID");
            new AlertDialog.Builder(this)
                .setTitle("👤 Admin ID बदला")
                .setView(input)
                .setPositiveButton("Save", (d, w) -> {
                    String id = input.getText().toString().trim();
                    if (!id.isEmpty()) { editor.putString("admin_id", id).apply(); Toast.makeText(this, "✅ Admin ID बदलला!", Toast.LENGTH_SHORT).show(); }
                })
                .setNegativeButton("रद्द करा", null).show();
        });

        // Logout
        Button btnLogout = findViewById(R.id.btnLogout);
        btnLogout.setOnClickListener(v -> finish());
    }

    @Override
    public boolean onSupportNavigateUp() { finish(); return true; }
}
