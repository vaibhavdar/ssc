package com.mahaboard.result;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.unity3d.ads.IUnityAdsInitializationListener;
import com.unity3d.ads.IUnityAdsLoadListener;
import com.unity3d.ads.IUnityAdsShowListener;
import com.unity3d.ads.UnityAds;
import com.unity3d.ads.UnityAdsShowOptions;
import com.unity3d.services.banners.BannerErrorInfo;
import com.unity3d.services.banners.BannerView;
import com.unity3d.services.banners.UnityBannerSize;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private ProgressBar progressBar;
    private LinearLayout bannerContainer;
    private LinearLayout noInternetLayout;
    private BannerView bannerView;
    private SharedPreferences prefs;
    private String currentUrl = "";
    private boolean adsInitialized = false;
    private boolean interstitialLoaded = false;
    private boolean rewardedLoaded = false;
    private boolean backPressedOnce = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("AdminPrefs", MODE_PRIVATE);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        webView          = findViewById(R.id.webView);
        progressBar      = findViewById(R.id.progressBar);
        bannerContainer  = findViewById(R.id.bannerContainer);
        noInternetLayout = findViewById(R.id.noInternetLayout);

        TextView btnRetry = findViewById(R.id.btnRetry);
        btnRetry.setOnClickListener(v -> loadUrl(currentUrl));

        setupWebView();

        // Load default SSC URL
        String sscUrl = prefs.getString("url_ssc", "https://sscresult.mkcl.org");
        if (getSupportActionBar() != null) getSupportActionBar().setTitle("SSC (10वी) निकाल");
        loadUrl(sscUrl);

        // Bottom Navigation — Interstitial on EVERY tab switch
        BottomNavigationView bottomNav = findViewById(R.id.bottomNav);
        bottomNav.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (adsInitialized && interstitialLoaded) showInterstitialAd();

            if (itemId == R.id.nav_ssc) {
                if (getSupportActionBar() != null) getSupportActionBar().setTitle("SSC (10वी) निकाल");
                loadUrl(prefs.getString("url_ssc", "https://sscresult.mkcl.org"));
            } else if (itemId == R.id.nav_hsc) {
                if (getSupportActionBar() != null) getSupportActionBar().setTitle("HSC (12वी) निकाल");
                loadUrl(prefs.getString("url_hsc", "https://hscresult.mkcl.org"));
            } else if (itemId == R.id.nav_board) {
                if (getSupportActionBar() != null) getSupportActionBar().setTitle("Maharashtra Board");
                loadUrl(prefs.getString("url_board", "https://mahahsscboard.in"));
            }
            return true;
        });

        initUnityAds();
    }

    // ───────────── WEBVIEW ─────────────

    private void setupWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView v, String url, Bitmap fav) {
                progressBar.setVisibility(View.VISIBLE);
                noInternetLayout.setVisibility(View.GONE);
                webView.setVisibility(View.VISIBLE);
            }
            @Override public void onPageFinished(WebView v, String url) {
                progressBar.setVisibility(View.GONE);
            }
            @Override public void onReceivedError(WebView v, int code, String desc, String url) {
                progressBar.setVisibility(View.GONE);
                if (!isNetworkAvailable()) {
                    noInternetLayout.setVisibility(View.VISIBLE);
                    webView.setVisibility(View.GONE);
                }
            }
        });
    }

    private void loadUrl(String url) {
        currentUrl = url;
        if (isNetworkAvailable()) {
            noInternetLayout.setVisibility(View.GONE);
            webView.setVisibility(View.VISIBLE);
            webView.loadUrl(url);
        } else {
            noInternetLayout.setVisibility(View.VISIBLE);
            webView.setVisibility(View.GONE);
        }
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        if (cm != null) { NetworkInfo n = cm.getActiveNetworkInfo(); return n != null && n.isConnected(); }
        return false;
    }

    // ───────────── UNITY ADS INIT ─────────────

    private void initUnityAds() {
        boolean adsEnabled = prefs.getBoolean("ads_enabled", true);
        String gameId      = prefs.getString("unity_game_id", "");
        boolean testMode   = prefs.getBoolean("test_mode", false);
        if (!adsEnabled || gameId.isEmpty()) return;

        UnityAds.initialize(this, gameId, testMode, new IUnityAdsInitializationListener() {
            @Override public void onInitializationComplete() {
                adsInitialized = true;
                runOnUiThread(() -> {
                    setupBannerAd();          // Banner — always visible
                    preloadInterstitial();    // Preload interstitial
                    showAppOpenRewarded();    // Rewarded — on first open
                });
            }
            @Override public void onInitializationFailed(UnityAds.UnityAdsInitializationError e, String m) {}
        });
    }

    // ───────────── 1. BANNER AD (always visible bottom) ─────────────

    private void setupBannerAd() {
        String pid = prefs.getString("banner_placement_id", "Banner_Android");
        bannerView = new BannerView(this, pid, UnityBannerSize.getDynamicSize(this));
        bannerView.setListener(new BannerView.IListener() {
            @Override public void onBannerLoaded(BannerView b) {}
            @Override public void onBannerClick(BannerView b) {}
            @Override public void onBannerFailedToLoad(BannerView b, BannerErrorInfo e) {
                // Retry every 30s
                new Handler().postDelayed(() -> { if (bannerView != null) bannerView.load(); }, 30000);
            }
            @Override public void onBannerLeftApplication(BannerView b) {}
        });
        bannerContainer.removeAllViews();
        bannerContainer.addView(bannerView);
        bannerView.load();
    }

    // ───────────── 2. APP OPEN REWARDED AD (App उघडताच) ─────────────

    private void showAppOpenRewarded() {
        String pid = prefs.getString("rewarded_placement_id", "Rewarded_Android");
        UnityAds.load(pid, new IUnityAdsLoadListener() {
            @Override public void onUnityAdsAdLoaded(String id) {
                rewardedLoaded = true;
                runOnUiThread(() -> UnityAds.show(MainActivity.this, id,
                    new UnityAdsShowOptions(), new IUnityAdsShowListener() {
                        @Override public void onUnityAdsShowFailure(String i, UnityAds.UnityAdsShowError e, String m) { rewardedLoaded = false; }
                        @Override public void onUnityAdsShowStart(String i) {}
                        @Override public void onUnityAdsShowClick(String i) {}
                        @Override public void onUnityAdsShowComplete(String i, UnityAds.UnityAdsShowCompletionState st) {
                            rewardedLoaded = false;
                        }
                    }));
            }
            @Override public void onUnityAdsFailedToLoad(String id, UnityAds.UnityAdsLoadError e, String m) {
                rewardedLoaded = false;
            }
        });
    }

    // ───────────── 3. INTERSTITIAL AD (tab switch + exit) ─────────────

    private void preloadInterstitial() {
        String pid = prefs.getString("interstitial_placement_id", "Interstitial_Android");
        UnityAds.load(pid, new IUnityAdsLoadListener() {
            @Override public void onUnityAdsAdLoaded(String id) { interstitialLoaded = true; }
            @Override public void onUnityAdsFailedToLoad(String id, UnityAds.UnityAdsLoadError e, String m) {
                interstitialLoaded = false;
                new Handler().postDelayed(() -> preloadInterstitial(), 5000);
            }
        });
    }

    private void showInterstitialAd() {
        String pid = prefs.getString("interstitial_placement_id", "Interstitial_Android");
        interstitialLoaded = false;
        UnityAds.show(this, pid, new UnityAdsShowOptions(), new IUnityAdsShowListener() {
            @Override public void onUnityAdsShowFailure(String id, UnityAds.UnityAdsShowError e, String m) { preloadInterstitial(); }
            @Override public void onUnityAdsShowStart(String id) {}
            @Override public void onUnityAdsShowClick(String id) {}
            @Override public void onUnityAdsShowComplete(String id, UnityAds.UnityAdsShowCompletionState st) { preloadInterstitial(); }
        });
    }

    // ───────────── EXIT AD (App बंद करताना) ─────────────

    private void showExitInterstitialAndClose() {
        if (!adsInitialized || !interstitialLoaded) { finish(); return; }
        String pid = prefs.getString("interstitial_placement_id", "Interstitial_Android");
        interstitialLoaded = false;
        UnityAds.show(this, pid, new UnityAdsShowOptions(), new IUnityAdsShowListener() {
            @Override public void onUnityAdsShowFailure(String id, UnityAds.UnityAdsShowError e, String m) { finish(); }
            @Override public void onUnityAdsShowStart(String id) {}
            @Override public void onUnityAdsShowClick(String id) {}
            @Override public void onUnityAdsShowComplete(String id, UnityAds.UnityAdsShowCompletionState st) { finish(); }
        });
    }

    // ───────────── BACK PRESS ─────────────

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) { webView.goBack(); return; }

        if (backPressedOnce) {
            showExitInterstitialAndClose();
            return;
        }
        backPressedOnce = true;
        Toast.makeText(this, "Exit करण्यासाठी पुन्हा Back दाबा", Toast.LENGTH_SHORT).show();
        new Handler().postDelayed(() -> backPressedOnce = false, 2000);
    }

    // ───────────── RESUME (App foreground ला आल्यावर rewarded) ─────────────

    @Override
    protected void onResume() {
        super.onResume();
        if (adsInitialized && !rewardedLoaded) {
            new Handler().postDelayed(this::showAppOpenRewarded, 1500);
        }
    }

    // ───────────── MENU ─────────────

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, 1, 0, "⚙ Admin");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == 1) {
            startActivity(new Intent(this, AdminLoginActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        if (bannerView != null) bannerView.destroy();
        super.onDestroy();
    }
}
