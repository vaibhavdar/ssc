# Maharashtra Board Result App
## Setup Instructions (सेटअप कसा करायचा)

### Step 1: Android Studio मध्ये Open करा
1. Android Studio open करा
2. "Open" वर click करा
3. हा folder निवडा: `MahaBoardResult`

### Step 2: Gradle Sync होऊ द्या
- Android Studio आपोआप dependencies download करेल
- Unity Ads SDK आपोआप install होईल

### Step 3: App Run करा
- एक physical Android phone जोडा किंवा Emulator start करा
- Run button दाबा ▶️

---

## Admin Panel कसा वापरायचा
1. App उघडल्यावर वरती **⚙ Admin** button दाबा
2. Default Login:
   - **ID:** `admin`
   - **Password:** `maha@2024`
3. Admin Panel मध्ये तुम्ही:
   - Unity Game ID टाकू शकता
   - Banner, Interstitial, Rewarded Placement IDs टाकू शकता
   - Test Mode ON/OFF करू शकता
   - Admin ID आणि Password बदलू शकता

---

## Unity Ads Game ID कुठून मिळेल?
1. https://dashboard.unity.com वर जा
2. Account बनवा / Login करा
3. New Project बनवा
4. Monetization → Ads → Game ID copy करा
5. Placement IDs पण तिथेच मिळतील

---

## App Features
- ✅ SSC (10वी) निकाल - sscresult.mkcl.org
- ✅ HSC (12वी) निकाल - hscresult.mkcl.org  
- ✅ Maharashtra Board - mahahsscboard.in
- ✅ Unity Banner Ad (खाली)
- ✅ Unity Interstitial Ad (दर 3 tabs switch नंतर)
- ✅ No Internet detection
- ✅ Admin Login Panel
- ✅ Admin ID/Password change करण्याची सोय
- ✅ Ads Enable/Disable करण्याची सोय
